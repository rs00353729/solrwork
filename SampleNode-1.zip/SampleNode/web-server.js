


    
    
    var fs = require('fs'),
    express = require('express'),
    bodyParser=require('body-parser');

    var outputFilename = "records.json";



//Code to Start Express

var webServiceApp=express();
webServiceApp.use(bodyParser());
webServiceApp.use(bodyParser.json());
webServiceApp.use(bodyParser.urlencoded());

var webServicePort=9004;


webServiceApp.get('/getUsers', function (req, res) {
	
	var file = fs.readFileSync(outputFilename, 'utf8');
	res.setHeader('Content-Type', 'JSON');
	res.end(file);	
	
	});

webServiceApp.post('/insertUsers',function(req,res){
	
	
	var jsonData = JSON.parse(req.body.mydata);
	var appender="";
	fs.readFile(outputFilename, 'utf8', function (err,data) {
		  if (err) {
		    console.log(err);
		    appender = "";
		  }
		  
		  
			 if (data.length && data.length > 0){ 
			  appender = ",";
			  console.log("has data");
		  }
			 console.log(appender);
			 
			 fs.appendFile(outputFilename, appender + JSON.stringify(jsonData), function(err) {
				    if(err) {
				      console.log(err);
				    }
				    else{
				    	console.log('Json saved');
				    	res.end();
				    }
				});
	});
	
	

});

webServiceApp.listen(webServicePort);
console.log('Express is Listening on port :' + webServicePort);


