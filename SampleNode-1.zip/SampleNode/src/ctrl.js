'use strict';
var app = angular.module("myApp",[]);

app.config(['$httpProvider', function($httpProvider) {
	$httpProvider.defaults.useXDomain = true;
	delete $httpProvider.defaults.headers.common['X-Requested-With'];
}
]);


app.controller("searchCtrl", function($scope,$http){
    
	$scope.searchNow = function(){
	console.log($scope.name);
	var method = 'GET';
	var searchUrl = 'http://localhost:8983/solr/sample/select?fq='+$scope.name+'&indent=on&q=*:*&wt=json';

		
		$http({ 
			method: 'GET',
			url: searchUrl,
			headers: {
				'Access-Control-Allow-Origin':true
				}
					
			}).
		success(function(data){
			console.log('success: '+data.response.docs.length);
			$scope.content = data.response.docs;
			console.log(data.response.docs);
			var j=0;
			for(var i=0;i<data.response.docs.length;i++)
			angular.forEach(data.response.docs[i], function(value, key) {
				
				console.log(value + "--"+ key);
			});
			console.log(data.response.docs);
			
		}).error(function (data){
			console.log('error');
			console.log(data);
		});
		};
	
        
	
});
app.controller("UserCtrl", function($scope,$http, $templateCache){
	var method = 'POST';
	var insertUrl = 'http://localhost:9004/insertUsers';
	$scope.codeStatus = "";
	$scope.callme = function(){
        var fil = document.getElementById("fileName");
        alert(fil.value);
           
        
    };
   
        
	$scope.save = function(){
		
		var formData = {
			'name': this.name,
			'Emp Id': this.empid,
			'Experience': this.exp
		};
		var jdata = 'mydata='+JSON.stringify(formData);
		alert(jdata);
		$http({ 
			method: method,
			url: insertUrl,
			data: jdata,
			headers: {'Content-Type': 'application/x-www-form-urlencoded'},
			cache: $templateCache
			}).success(function(response){
				console.log("success");
				$scope.codeStatus = response.data;
				console.log($scope.codeStatus);
			}).error(function(response){
				console.log("error");
				$scope.codeStatus = response || "Request failed";
				console.log($scope.codeStatus);
			});
			
        
      
        
		return false;
	};
});