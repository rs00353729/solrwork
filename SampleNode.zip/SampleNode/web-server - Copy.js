

var sys = require('sys'),
    http = require('http'),
    url = require('url'),
    fs = require('fs'),
    express = require('express'),
    bodyParser=require('body-parser');

var outputFilename = "records.json";

var DEFAULT_PORT = 80;

function main(argv) {
  new HttpServer({
    'GET': createServlet(StaticServlet),
    'HEAD': createServlet(StaticServlet)
  }).start(Number(argv[2]) || DEFAULT_PORT);
}

function escapeHtml(value) {
  return value.toString().
    replace('<', '&lt;').
    replace('>', '&gt;').
    replace('"', '&quot;');
}

function createServlet(Class) {
  var servlet = new Class();
  return servlet.handleRequest.bind(servlet);
}

/**
 * An Http server implementation that uses a map of methods to decide
 * action routing.
 *
 * @param {Object} Map of method => Handler function
 */
function HttpServer(handlers) {
  this.handlers = handlers;
  this.server = http.createServer(this.handleRequest_.bind(this));
}

HttpServer.prototype.start = function(port) {
  this.port = port;
  this.server.listen(port);
  sys.puts('Http Server running at http://localhost:' + port + '/');
};

HttpServer.prototype.parseUrl_ = function(urlString) {
  var parsed = url.parse(urlString);
  parsed.pathname = url.resolve('/', parsed.pathname);
  return url.parse(url.format(parsed), true);
};

HttpServer.prototype.handleRequest_ = function(req, res) {
  var logEntry = req.method + ' ' + req.url;
  if (req.headers['user-agent']) {
    logEntry += ' ' + req.headers['user-agent'];
  }
  sys.puts(logEntry);
  req.url = this.parseUrl_(req.url);
  var handler = this.handlers[req.method];
  if (!handler) {
    res.writeHead(501);
    res.end();
  } else {
    handler.call(this, req, res);
  }
};

/**
 * Handles static content.
 */
function StaticServlet() {}

StaticServlet.MimeMap = {
  'txt': 'text/plain',
  'html': 'text/html',
  'css': 'text/css',
  'xml': 'application/xml',
  'json': 'application/json',
  'js': 'application/javascript',
  'jpg': 'image/jpeg',
  'jpeg': 'image/jpeg',
  'gif': 'image/gif',
  'png': 'image/png'
};

StaticServlet.prototype.handleRequest = function(req, res) {
  var self = this;
  var path = ('./' + req.url.pathname).replace('//','/').replace(/%(..)/, function(match, hex){
    return String.fromCharCode(parseInt(hex, 16));
  });
  var parts = path.split('/');
  if (parts[parts.length-1].charAt(0) === '.')
    return self.sendForbidden_(req, res, path);
  fs.stat(path, function(err, stat) {
    if (err)
      return self.sendMissing_(req, res, path);
    if (stat.isDirectory())
      return self.sendDirectory_(req, res, path);
    return self.sendFile_(req, res, path);
  });
}

StaticServlet.prototype.sendError_ = function(req, res, error) {
  res.writeHead(500, {
      'Content-Type': 'text/html'
  });
  res.write('<!doctype html>\n');
  res.write('<title>Internal Server Error</title>\n');
  res.write('<h1>Internal Server Error</h1>');
  res.write('<pre>' + escapeHtml(sys.inspect(error)) + '</pre>');
  sys.puts('500 Internal Server Error');
  sys.puts(sys.inspect(error));
};

StaticServlet.prototype.sendMissing_ = function(req, res, path) {
  path = path.substring(1);
  res.writeHead(404, {
      'Content-Type': 'text/html'
  });
  res.write('<!doctype html>\n');
  res.write('<title>404 Not Found</title>\n');
  res.write('<h1>Not Found</h1>');
  res.write(
    '<p>The requested URL ' +
    escapeHtml(path) +
    ' was not found on this server.</p>'
  );
  res.end();
  sys.puts('404 Not Found: ' + path);
};

StaticServlet.prototype.sendForbidden_ = function(req, res, path) {
  path = path.substring(1);
  res.writeHead(403, {
      'Content-Type': 'text/html'
  });
  res.write('<!doctype html>\n');
  res.write('<title>403 Forbidden</title>\n');
  res.write('<h1>Forbidden</h1>');
  res.write(
    '<p>You do not have permission to access ' +
    escapeHtml(path) + ' on this server.</p>'
  );
  res.end();
  sys.puts('403 Forbidden: ' + path);
};

StaticServlet.prototype.sendRedirect_ = function(req, res, redirectUrl) {
  res.writeHead(301, {
      'Content-Type': 'text/html',
      'Location': redirectUrl
  });
  res.write('<!doctype html>\n');
  res.write('<title>301 Moved Permanently</title>\n');
  res.write('<h1>Moved Permanently</h1>');
  res.write(
    '<p>The document has moved <a href="' +
    redirectUrl +
    '">here</a>.</p>'
  );
  res.end();
  sys.puts('301 Moved Permanently: ' + redirectUrl);
};

StaticServlet.prototype.sendFile_ = function(req, res, path) {
  var self = this;
  var file = fs.createReadStream(path);
  res.writeHead(200, {
    'Content-Type': StaticServlet.
      MimeMap[path.split('.').pop()] || 'text/plain'
  });
  if (req.method === 'HEAD') {
    res.end();
  } else {
    file.on('data', res.write.bind(res));
    file.on('close', function() {
      res.end();
    });
    file.on('error', function(error) {
      self.sendError_(req, res, error);
    });
  }
};

StaticServlet.prototype.sendDirectory_ = function(req, res, path) {
  var self = this;
  if (path.match(/[^\/]$/)) {
    req.url.pathname += '/';
    var redirectUrl = url.format(url.parse(url.format(req.url)));
    return self.sendRedirect_(req, res, redirectUrl);
  }
  fs.readdir(path, function(err, files) {
    if (err)
      return self.sendError_(req, res, error);

    if (!files.length)
      return self.writeDirectoryIndex_(req, res, path, []);

    var remaining = files.length;
    files.forEach(function(fileName, index) {
      fs.stat(path + '/' + fileName, function(err, stat) {
        if (err)
          return self.sendError_(req, res, err);
        if (stat.isDirectory()) {
          files[index] = fileName + '/';
        }
        if (!(--remaining))
          return self.writeDirectoryIndex_(req, res, path, files);
      });
    });
  });
};

StaticServlet.prototype.writeDirectoryIndex_ = function(req, res, path, files) {
  path = path.substring(1);
  res.writeHead(200, {
    'Content-Type': 'text/html'
  });
  if (req.method === 'HEAD') {
    res.end();
    return;
  }
  res.write('<!doctype html>\n');
  res.write('<title>' + escapeHtml(path) + '</title>\n');
  res.write('<style>\n');
  res.write('  ol { list-style-type: none; font-size: 1.2em; }\n');
  res.write('</style>\n');
  res.write('<h1>Directory: ' + escapeHtml(path) + '</h1>');
  res.write('<ol>');
  files.forEach(function(fileName) {
    if (fileName.charAt(0) !== '.') {
      res.write('<li><a href="' +
        escapeHtml(fileName) + '">' +
        escapeHtml(fileName) + '</a></li>');
    }
  });
  res.write('</ol>');
  res.end();
};

// Must be last,
main(process.argv);

//Code to Start Express

var webServiceApp=express();
webServiceApp.use(bodyParser());
webServiceApp.use(bodyParser.json());
webServiceApp.use(bodyParser.urlencoded());

var webServicePort=9004;
//webServiceApp.use(express.static(__dirname + '/app'));
webServiceApp.all('*', function(req, res, next) {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'PUT, GET, POST, DELETE, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Content-Type');
  next();
});
var router = express.Router();
webServiceApp.use('/api', router);


router.get('/test', function(req, res) {

	var helloJson={'message':'hello from express'};
	res.json(helloJson);
});

var handleDataCalls=function (model,schema,res){

if(mongoose.connection.db.serverConfig._serverState=="connected"&&mongoose.connection._readyState==1){
 	var poc_comp=mongoose.model(model,schema);

	   // Find all POCs.
	   poc_comp.find(function(err, pocs) {
        if (err) return console.error(err);
           console.log('reading from mongoDB'+model);
	       res.json(pocs);
       });
      }else{
            // get data from json
                console.log('reading from file'+model);
                var file = fs.readFileSync(__dirname+'/data/JSON/'+model+'.json', 'utf8');
                res.json(JSON.parse(file));


        }
}
router.get('/getData', function(req, res) {



            var collectionType=req.query.collection;
            if(collectionType=='POC_Completed'){

                handleDataCalls('POC_Completed',POCCompletedSchema,res);

            }else if(collectionType=='POC_InProgress'){

                handleDataCalls('POC_InProgress',POCInProgressSchema,res);

            }else if(collectionType=='RnD'){

                handleDataCalls('RnD',RnDSchema,res);

            }else if(collectionType=='Highlights'){

                handleDataCalls('Highlights',HighlightsSchema,res);

            }


});

router.get('/getFileCategoryList', function(req, res) {

    var FileSystemModel=mongoose.model('Files',FileSystemSchema);
    FileSystemModel.find().distinct('category', function(error, categories) {
    res.json(categories);
});

});

router.get('/getFileSubCategoryList', function(req, res) {
    var category=req.query.category;
    var FileSystemModel=mongoose.model('Files',FileSystemSchema);
    FileSystemModel.find({"category":category}).distinct('subCategory',function(err, subcategories) {
        res.json(subcategories);
});
});
router.get('/getFileList', function(req, res) {
    var category=req.query.category;
    var subCategory=req.query.subcategory;
    var FileSystemModel=mongoose.model('Files',FileSystemSchema);
    FileSystemModel.find({"category":category,"subCategory":subCategory},function(err, files) {
        res.json(files);
    });

    //TODO if user provides no Categy and subCategory it should return all


});



router.get('/getMonthEvent', function(req, res) {
    var month=req.query.month;
    var year=req.query.year;
    var EventsModel=mongoose.model('Events',EventsSchema);


    EventsModel.find({"eventMonth":Number(month),"eventYear":Number(year)},{_id:0}).sort([['eventDay', 'desc']]).select('eventHeading eventDescription eventFiles eventDay').exec(function(err,events) {
        //events

	if ( err ) {
		console.log("Exception occured. Please try after some time.");
	}
	else{
        var evobj=new Array();
        for(var i=0;i<events.length;i++){
            //user = user.toObject();
            var event=events[i].toObject();
            event.eventDate=year+"-"+month+"-"+events[i].eventDay;
            delete event.eventDay;
            evobj.push(event);

           // console.log(evobj[i].eventDate);
            //console.log(event.eventDay);
           // delete event.eventDay;

        }
        //console.log(evobj);
        res.json(evobj);

}
    });
});
/*router.get('/getFileList', function(req, res) {
    var category=req.query.category;
    var subCategory=req.query.subcategory;
    var FileSystemModel=mongoose.model('Files',FileSystemSchema);
    FileSystemModel.find({"EventsModel":,"subCategory":subCategory},function(err, files) {
        res.json(files);
    });

    //TODO if user provides no Categy and subCategory it should return all


});
*/

router.post('/authenticate',function(req,res){
    var userName=req.body.login;
    var password=req.body.password;

     //mongo code to Search
    var User=mongoose.model('User',UserSchema);
    if(mongoose.connection.db.serverConfig._serverState=="connected"&&mongoose.connection._readyState==1){

    User.findOne({"username":userName,"password":password},function(err, Users) {
        if (err) return console.error(err);
        if(Users!=null) res.json({"Status": "Success","Role" : Users.role});
        else res.json({"Status": "Failure","Message" : "Wrong User or Password."});
});
    }else{
        res.json({"Status": "Failure","Message" : "No Logon Servers available."})
    }

});
router.get('/getContent', function(req, res) {
	res.data = "Hello";
	 console.log("helo here ");
    });

router.post('/writeIntoJson',function(req,res){

	 console.log("In writeintojsons ");
});
router.post('/postNewHighlights',function(req,res){

   console.log(req.body);
   // console.log(req.files);
    console.log(req.files);

    //get all the details about the event
    var eventHeading=req.body.heading;
    var eventDescription=req.body.description;
    var eventFiles=req.files.eventFiles;
    var eventDate=req.body.date;
    var eventDateArr=eventDate.split('-');
    var eventYear=eventDateArr[0];
    var eventMonth=eventDateArr[1];
    var eventDay=eventDateArr[2];
    var eventAuthor=req.body.eventAuthor;



    //call mongoDB and Save the event object

    var Event=mongoose.model('Events',EventsSchema);


    var fileArrayStr='['
   // console.log(eventFiles);
    if(eventFiles){

    //make a dir Datestamp_author
    var eventDirectory=Number(new Date())+'_'+eventAuthor;
       // console.log(eventDirectory);
        var highlightStorePath="img/events/"
        var eventDirectoryFullPath=highlightStorePath+eventDirectory;

        fs.mkdirSync(eventDirectoryFullPath);


          //  console.log(fileArrayStr);
        //console.log(eventFiles);
       if(typeof eventFiles.length == 'undefined'){
       var tmp=eventFiles;
        eventFiles=new Array();
           eventFiles.push(tmp);

       }
           //console.log(eventFiles.isArray);
            for(var i=0;i<eventFiles.length;i++){

           var writeFilePath=eventDirectoryFullPath+"/"+eventFiles[i].originalname;

            fs.createReadStream(eventFiles[i].path).pipe(fs.createWriteStream(writeFilePath));

           fileArrayStr+='{"displayName":"'+eventFiles[i].originalname+'","downloadPath":"'+writeFilePath+'","fileExtention":"'+eventFiles[i].extension+'"},';        console.log(fileArrayStr);

            }


            fileArrayStr=fileArrayStr.substr(0,fileArrayStr.length-1);
            }

            fileArrayStr+=']';

      // console.log("file arr"+fileArrayStr)
    var addEvent= new Event({
		  eventHeading:eventHeading,
		  eventDescription:eventDescription,
          eventFiles:JSON.parse(fileArrayStr),
		  eventYear:eventYear,
          eventMonth:eventMonth,
          eventDay:eventDay,
          eventAuthor:eventAuthor


	});




	addEvent.save(function(err, addedEvent) {
        if (err)
        {
            console.error(err);
            res.json({"Status":"Failure","Message":"There has been error,Please try after some time."});
            //return console.error(err);
        }

        res.json({"Status":"Success","Message":"data saved successfully"});

	});

    });


//Post New Area
router.post('/postNewProjectArea',function(req,res){


   console.log(req.body);
   // console.log(req.files);
    console.log(req.files);

    //get all the details about the event
    var areaHeading=req.body.heading;
     var areaBrief=req.body.areaBrief;
    var areaDescription=req.body.description;
    var areaFiles=req.files.projectAreaFiles;
    var areaImage=req.files.projectAreaImage;
    var areaAuthor=req.body.areaAuthor;



    //call mongoDB and Save the event object

    var Area=mongoose.model('ProjectArea',AreaSchema);


    var fileArrayStr='[';
    var  imageArrayStr='[';
   // console.log(eventFiles);
    if(areaFiles||areaImage){

    //make a dir Datestamp_author
    var areaDirectory=Number(new Date())+'_'+areaAuthor;
       // console.log(eventDirectory);
        var areaStorePath="img/projects/area/"
        var areaDirectoryFullPath=areaStorePath+areaDirectory;

        fs.mkdirSync(areaDirectoryFullPath);


          //  console.log(fileArrayStr);
        //console.log(eventFiles);
       /*if(typeof areaFiles == 'undefined'){
       var tmp=areaFiles;
        areaFiles=new Array();
           areaFiles.push(tmp);

       }
*/
           if(typeof areaFiles != 'undefined'){
            for(var i=0;i<areaFiles.length;i++){

           var writeFilePath=areaDirectoryFullPath+"/"+areaFiles[i].originalname;

            fs.createReadStream(areaFiles[i].path).pipe(fs.createWriteStream(writeFilePath));

           fileArrayStr+='{"displayName":"'+areaFiles[i].originalname+'","downloadPath":"'+writeFilePath+'","fileExtention":"'+areaFiles[i].extension+'"},';

            }
          }

            fileArrayStr=fileArrayStr.substr(0,fileArrayStr.length-1);

if(areaImage){
            var imageDirectoryFullPath=areaDirectoryFullPath+"/"+"img";
            fs.mkdirSync(imageDirectoryFullPath);
              var writeImagePath=imageDirectoryFullPath+"/"+areaImage.originalname;
            fs.createReadStream(areaImage.path).pipe(fs.createWriteStream(writeImagePath));
        imageArrayStr+='{"displayName":"'+areaImage.originalname+'","downloadPath":"'+writeImagePath+'","fileExtention":"'+areaImage.extension+'"}';
    }

            }
        imageArrayStr+=']';
        fileArrayStr+=']';




      // console.log("file arr"+fileArrayStr)
    var addArea= new Area({
		  areaHeading:areaHeading,
		  areaDescription:areaDescription,
          areaBrief:areaBrief,
         // areaFiles:JSON.parse(fileArrayStr),
          areaImage:JSON.parse(imageArrayStr),
		  areaAuthor:areaAuthor
	});


	addArea.save(function(err, addedEvent) {
        if (err)
        {
            console.error(err);
            res.json({"Status":"Failure","Message":"There has been error,Please try after some time."});
            //return console.error(err);
        }

        res.json({"Status":"Success","Message":"data saved successfully"});

	});

    });
/* Ranjit */
router.get('/getProjects', function(req, res) {

    var projModel=mongoose.model('Projects',ProjectsSchema);


    projModel.find({},{_id:0}).select('projectID projectType').exec(function(err,projects) {
    if (err) {
            console.error(err);
    }else
        res.json(projects);
    });

    //TODO if user provides no Categy and subCategory it should return all


});

router.get('/getProjectAreas', function(req, res) {

    var AreaModel=mongoose.model('ProjectArea',AreaSchema);


    AreaModel.find({},{_id:0}).select('areaID areaHeading').exec(function(err,areas) {
		if (err) {
            console.error(err);
		}else
        res.json(areas);
    });

    //TODO if user provides no Categy and subCategory it should return all


});

//router.get()

router.post('/postNewProjects',function(req,res){

    var imageArrayStr="[";
    var Project=mongoose.model('Projects',ProjectsSchema);
   console.log(req.body);

    console.log(req.files);

    var projectHeading=req.body.projectName;
    var projectBrief=req.body.projectBrief;
    var projectAreaID=req.body.projectArea;
    var projectType=req.body.projectType;
    var projectDescription=req.body.projectDescription;
    var projectImages=req.files;
    var primaryImage=req.body.primaryImage;
    var projectAuthor=req.body.projectAuthor;
    var projectDirectory=Number(new Date())+'_'+projectAuthor;
       // console.log(eventDirectory);
        var projectStorePath="img/projects/"
        var projectDirectoryFullPath=projectStorePath+projectDirectory;


    if(projectImages){
        //read JSON Key value


        console.log(projectImages.length);
         fs.mkdirSync(projectDirectoryFullPath);
        for (var prop in projectImages) {
        if (projectImages.hasOwnProperty(prop)) {
            console.log(prop);
           // console.log(projectImages[prop]);
            var projectImage=projectImages[prop]
            var elementID=prop.split('_')[1];



            var writeImagePath=projectDirectoryFullPath+"/"+projectImage.originalname;
            fs.createReadStream(projectImage.path).pipe(fs.createWriteStream(writeImagePath));


            var projectImageDescription=req.body['fileDescription_'+elementID];

            if(typeof projectImageDescription== 'undefined'){
            projectImageDescription='';
            }

            console.log("elementID: "+elementID+",projectImageDescription: "+projectImageDescription);

            //TODO : Image array is comming two times
                                imageArrayStr+='{"displayName":"'+projectImage.originalname+'","downloadPath":"'+writeImagePath+'","fileExtention":"'+projectImage.extension+'","fileDescription":"'+projectImageDescription+'","isPrimary":"'+(elementID==primaryImage)+'"},';
        }
    }

    //var projectDescription=req.body.projectDescription;

        //console.log(imageArrayStr);

	 /*   projectHeading:String,
        projectBrief:String,
        projectAreaID:[Number],
        projectStatus:String,
	    projectDescription:String,
        projectFiles:[fileDescSchema],
        projectAuthor:String
*/
         imageArrayStr=imageArrayStr.substr(0,imageArrayStr.length-1);
    }
    imageArrayStr+="]";
    console.log(imageArrayStr);

    //save here

    var addProject=new Project({

	    projectHeading:projectHeading,
        projectBrief:projectBrief,
        projectAreaID:JSON.parse('['+projectAreaID+']'),
        projectType:projectType,
	    projectDescription:projectDescription,
        projectFiles:JSON.parse(imageArrayStr),
        projectAuthor:projectAuthor

        //,dateAdded:Date

	});
    	addProject.save(function(err, addedEvent) {


      //var serverName = confObj.serverName;


        var projectId = addedEvent["projectID"];
        var projectType = addedEvent["projectType"];
        var projectDescription = addedEvent["projectDescription"];
        var os = require("os");
        console.log("$$$$$$ Ranjit : "+os.hostname()+"port:"+DEFAULT_PORT);
        var url = "#/"+projectType+"/"+projectId;

          console.log(" URL:  :"+url);
        writeFile("searchurls.properties",projectId+"="+url+"\n");
        writeFile("searchactions.properties",projectId+"="+projectDescription+"\n");


        if (err)
        {
            console.error(err);
            res.json({"Status":"Failure","Message":"There has been error,Please try after some time."});
            //return console.error(err);
        }

        res.json({"Status":"Success","Message":"data saved successfully"});

	});


});






function writeFile(outputFilename,myData){
      console.log("Ranjit : In writeFile");

  fs.appendFile(outputFilename, myData, function(err) {
    if(err) {
      console.log(err);
    }
});
}

router.get('/getProjectStatus', function(req, res) {


    var CommonDataModel=mongoose.model('CommonData',CommonDataSchema);


    CommonDataModel.find(function(err,comData) {
		if (err) {
            console.error(err);
		}else
        res.json(comData[0].ProjectTypes);
});



});


router.post('/postData',function(req,res){


    console.log(req.body.data);
    var myData=req.body.data;


     //mongo code to Search
    var Files=mongoose.model('Files',FileSystemSchema);
    if(mongoose.connection.db.serverConfig._serverState=="connected"&&mongoose.connection._readyState==1){
	Files.find().remove(function(err) {
    if (!err) {

			var collectionF=mongoose.connection.collection('Files').insert(myData,function(){});
			res.json(myData);

    }else{

			res.json({"Status": "Failure","Message" : "Failed to Perform delete","message":err});
	}

	});
//docs.remove();


    }else{
        res.json({"Status": "Failure","Message" : "No Logon Servers available."})
    }

});


/*Get Projects based on Project Area and project Type: Start: Seema*/

router.get('/getProjectsByProjID', function(req, res) {

    var projectID = req.query.projectID;
    var Project=mongoose.model('Projects',ProjectsSchema);

    Project.find({"projectID": Number(projectID)},{_id:0, __v:0, "projectFiles._id":0}).exec(function(err,projects) {
        res.json(projects);
    });

    //TODO if user provides no Area and Project Type, it should return all
});



router.get('/getProjectsByAreaNType', function(req, res) {

    var project_type = req.query.projectType;
    var areaID = req.query.projectAreaID;
    var Project=mongoose.model('Projects',ProjectsSchema);

    Project.find({"projectType": project_type, "projectAreaID": Number(areaID)},{_id:0, __v:0, "projectFiles._id":0}).exec(function(err,projects) {
        res.json(projects);
    });

    //TODO if user provides no Area and Project Type, it should return all
});



router.get('/getProjectAreasByType', function(req, res) {

    var project_type = req.query.projectType;
    var Project=mongoose.model('Projects',ProjectsSchema);

    Project.find({"projectType": project_type}).distinct('projectAreaID', function(err,projectAreaID) {

        var AreaModel=mongoose.model('ProjectArea',AreaSchema);

        AreaModel.find({areaID: {$in: projectAreaID}},{_id:0}).select('areaID areaHeading areaDescription areaImage').exec(function(err,areas) {
            res.json(areas);
        });
    });

});

/*Get Projects based on Project Area and project Type: End: Seema*/

function readFile(fileName){
fs.readFile(fileName, 'utf8', function (err,data) {
	  if (err) {
	    console.log(err);
	    return "false";
	  }
	    if (data=="") return "false";
	    else 
	    	return "true"; 
	    
	});
}
webServiceApp.get('/getUsers', function (req, res) {
	
	var file = fs.readFileSync(outputFilename, 'utf8');
	
	res.setHeader('Content-Type', 'text/plain');
	

		res.end(file);	
	
	});

webServiceApp.post('/insertUsers',function(req,res){
	
	res.header("Access-Control-Allow-Origin", "http://localhost");
	res.header("Access-Control-Allow-Methods", "GET, POST");
	
	req.header("Origin","http://localhost");
	console.log("Post :: \n\n\n -- > ");
	
	console.log(req.url);
	console.log(req.body.mydata);
	var jsonData = JSON.parse(req.body.mydata);
	console.log("Calling read... \n");
	
	var appender="";
	fs.readFile(outputFilename, 'utf8', function (err,data) {
		  if (err) {
		    console.log(err);
		    appender = "";
		  }
		  
		  
			 if (data.length && data.length > 0){ 
			  appender = ",";
			  console.log("has data");
		  }
			 console.log(appender);
			 
			 fs.appendFile(outputFilename, appender + JSON.stringify(jsonData), function(err) {
				    if(err) {
				      console.log(err);
				    }
				    else{
				    	console.log('Json saved');
				    	res.end();
				    }
				});
	});
	
	

});

webServiceApp.listen(webServicePort);
console.log('Express is Listening on port :' + webServicePort);
function writeFile(outputFilename){
	
	
}

