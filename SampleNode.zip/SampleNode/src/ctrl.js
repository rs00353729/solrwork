'use strict';
var app = angular.module("myApp",[]);

app.config(['$httpProvider', function($httpProvider) {
	$httpProvider.defaults.useXDomain = true;
	delete $httpProvider.defaults.headers.common['X-Requested-With'];
}
]);

app.controller("searchCtrl", function($scope,$http, $templateCache){
    var method = 'GET';
	var insertUrl = 'http://localhost:8983/insertUsers';
});
app.controller("UserCtrl", function($scope,$http, $templateCache){
	var method = 'POST';
	var insertUrl = 'http://localhost:9004/insertUsers';
	$scope.codeStatus = "";
	$scope.callme = function(){
        var fil = document.getElementById("fileName");
        alert(fil.value);
           
        
    };
   
        
	$scope.save = function(){
		
		var formData = {
			'name': this.name,
			'Emp Id': this.empid,
			'Experience': this.exp
		};
		var jdata = 'mydata='+JSON.stringify(formData);
		alert(jdata);
		$http({ 
			method: method,
			url: insertUrl,
			data: jdata,
			headers: {'Content-Type': 'application/x-www-form-urlencoded'},
			cache: $templateCache
			}).success(function(response){
				console.log("success");
				$scope.codeStatus = response.data;
				console.log($scope.codeStatus);
			}).error(function(response){
				console.log("error");
				$scope.codeStatus = response || "Request failed";
				console.log($scope.codeStatus);
			});
        
        $http({
            method: 'GET',
            url: 'curl http://localhost:8983/solr/demo/update -H "Content-Type: text/xml" --data-binary @records.json'
        });
        
		return false;
	};
});